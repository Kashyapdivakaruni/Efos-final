from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
import pdfplumber
import io
import json

from backend.database import get_db, Patient, CheckIn
from backend.ollama_service import extract_metrics_from_text
from backend.routers.checkin import perform_ml_inference

router = APIRouter(prefix="/api/upload", tags=["upload"])

@router.post("/lab-report")
async def upload_lab_report(patient_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    if not file.filename.endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are supported currently")

    try:
        content = await file.read()
        extracted_text = ""
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    extracted_text += text + "\n"
        
        if not extracted_text.strip():
            raise HTTPException(status_code=400, detail="Could not extract text from PDF")

        metrics = await extract_metrics_from_text(extracted_text)

        # Fill missing metrics with patient baseline or default
        bp_systolic = metrics.get('bp_systolic', 120)
        bp_diastolic = metrics.get('bp_diastolic', 80)
        heart_rate = metrics.get('heart_rate', 75)
        glucose = metrics.get('glucose', patient.glucose_baseline)
        cholesterol = metrics.get('cholesterol', patient.cholesterol_baseline)
        sleep_hours = metrics.get('sleep_hours', 7.0)

        # Create checkin
        ci = CheckIn(
            patient_id=patient.id,
            bp_systolic=bp_systolic,
            bp_diastolic=bp_diastolic,
            weight=metrics.get('weight', 70.0), # Default if not found
            mood=7, # Default
            sleep_hours=sleep_hours,
            spo2=metrics.get('spo2', 98.0),
            heart_rate=heart_rate,
            glucose=glucose
        )
        db.add(ci)
        db.commit()
        db.refresh(ci)

        # Run ML Inference
        from backend.main import ml_engine, shap_explainer
        perform_ml_inference(ci, patient, db, ml_engine, shap_explainer)

        return {"message": "Report processed successfully", "metrics_extracted": metrics, "checkin_id": ci.id}

    except Exception as e:
        print(f"Error processing upload: {e}")
        raise HTTPException(status_code=500, detail=str(e))
