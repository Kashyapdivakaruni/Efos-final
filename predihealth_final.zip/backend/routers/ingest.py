from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import Dict
import tempfile
import os
import re
import base64
import os as os_module

router = APIRouter(prefix="/api/ingest", tags=["ingest"])

try:
    from PIL import Image
    import pytesseract
    import pdfplumber
    LOCAL_OCR_AVAILABLE = True
except Exception:
    LOCAL_OCR_AVAILABLE = False

try:
    from google.cloud import vision
    GOOGLE_VISION_AVAILABLE = True
except Exception:
    GOOGLE_VISION_AVAILABLE = False

import httpx

GOOGLE_VISION_API_KEY = os_module.getenv("GOOGLE_VISION_API_KEY", "")


def extract_numbers_from_text(text: str) -> Dict[str, float]:
    # Basic regex-based extraction for vitals
    out = {}
    bp_match = re.search(r"(\d{2,3})\s*[\/:]\s*(\d{2,3})", text)
    if bp_match:
        out["bp_systolic"] = int(bp_match.group(1))
        out["bp_diastolic"] = int(bp_match.group(2))

    glucose = re.search(r"glucose[:\s]*([0-9]{2,3})", text, re.IGNORECASE)
    if glucose:
        out["glucose"] = float(glucose.group(1))

    spo2 = re.search(r"(SpO2|SpO2:|spo2)\s*[:=]?\s*([0-9]{2,3})", text, re.IGNORECASE)
    if spo2:
        out["spo2"] = float(spo2.group(2))

    hr = re.search(r"(HR|Heart Rate)[:\s]*([0-9]{2,3})", text, re.IGNORECASE)
    if hr:
        out["heart_rate"] = int(hr.group(2))

    return out


def extract_text_local(file_path: str) -> str:
    """Extract text using local pytesseract or pdfplumber"""
    if not LOCAL_OCR_AVAILABLE:
        return ""
    
    try:
        suffix = os.path.splitext(file_path)[1].lower()
        text = ""
        if suffix in ['.pdf']:
            with pdfplumber.open(file_path) as pdf:
                for p in pdf.pages[:5]:
                    text += p.extract_text() or ""
        else:
            img = Image.open(file_path)
            text = pytesseract.image_to_string(img)
        return text
    except Exception as e:
        print(f"Local OCR failed: {e}")
        return ""


async def extract_text_google_cloud(file_path: str) -> str:
    """Extract text using Google Cloud Vision API"""
    if not GOOGLE_VISION_AVAILABLE:
        return ""
    
    try:
        client = vision.ImageAnnotatorClient()
        with open(file_path, "rb") as f:
            image_content = f.read()
        image = vision.Image(content=image_content)
        response = client.document_text_detection(image=image)
        return response.full_text_annotation.text
    except Exception as e:
        print(f"Google Cloud Vision failed: {e}")
        return ""


async def extract_text_google_api_key(file_path: str) -> str:
    """Extract text using Google Vision API with API key (no service account)"""
    if not GOOGLE_VISION_API_KEY:
        return ""
    
    try:
        with open(file_path, "rb") as f:
            image_bytes = f.read()
        
        base64_image = base64.b64encode(image_bytes).decode('utf-8')
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"https://vision.googleapis.com/v1/images:annotate?key={GOOGLE_VISION_API_KEY}",
                json={
                    "requests": [
                        {
                            "image": {"content": base64_image},
                            "features": [
                                {"type": "DOCUMENT_TEXT_DETECTION"},
                                {"type": "TEXT_DETECTION"},
                            ]
                        }
                    ]
                }
            )
        
        if response.status_code == 200:
            data = response.json()
            if data.get("responses") and data["responses"][0].get("fullTextAnnotation"):
                return data["responses"][0]["fullTextAnnotation"].get("text", "")
    except Exception as e:
        print(f"Google Vision API key method failed: {e}")
    
    return ""


@router.post("/report")
async def ingest_report(file: UploadFile = File(...)):
    suffix = os.path.splitext(file.filename)[1].lower()
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        content = await file.read()
        tmp.write(content)
        tmp.flush()
        
        # Try local OCR first
        text = extract_text_local(tmp.name)
        
        # If local OCR failed or not available, try Google Cloud Vision
        if not text:
            text = await extract_text_google_cloud(tmp.name)
        
        # If Google Cloud Vision failed, try API key method
        if not text:
            text = await extract_text_google_api_key(tmp.name)
        
        # If all OCR methods failed
        if not text:
            raise HTTPException(
                status_code=503,
                detail="No OCR service available. Install pytesseract locally or set GOOGLE_VISION_API_KEY."
            )

        parsed = extract_numbers_from_text(text)
        return {
            "text_excerpt": text[:800],
            "parsed": parsed,
            "method": "local_ocr" if LOCAL_OCR_AVAILABLE else "cloud_ocr"
        }
    finally:
        try:
            tmp.close()
            os.unlink(tmp.name)
        except Exception:
            pass
