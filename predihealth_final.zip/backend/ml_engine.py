import numpy as np
import pandas as pd
from xgboost import XGBClassifier
import shap
import joblib
import os
import json

MODELS_DIR = os.path.join(os.path.dirname(__file__), "saved_models")
FEATURE_NAMES = [
    "age", "gender", "bmi", "bp_systolic", "bp_diastolic",
    "glucose", "cholesterol", "hdl", "ldl", "sleep_hours",
    "heart_rate", "spo2", "smoker", "family_diabetes", "family_cardiac", "mood"
]

_models = {}
_explainers = {}


def get_models():
    global _models, _explainers
    if _models:
        return _models, _explainers

    os.makedirs(MODELS_DIR, exist_ok=True)
    model_files = {
        "diabetes": os.path.join(MODELS_DIR, "diabetes_model.pkl"),
        "cardiac": os.path.join(MODELS_DIR, "cardiac_model.pkl"),
        "hypertension": os.path.join(MODELS_DIR, "hypertension_model.pkl"),
        "metabolic": os.path.join(MODELS_DIR, "metabolic_model.pkl"),
    }

    if not all(os.path.exists(f) for f in model_files.values()):
        print("[SETUP] Training ML models (first run)...")
        from train_models import train_and_save
        train_and_save()

    for name, path in model_files.items():
        model = joblib.load(path)
        _models[name] = model
        _explainers[name] = shap.TreeExplainer(model)

    print("[OK] ML models loaded.")
    return _models, _explainers


def build_feature_vector(patient, checkin):
    weight = checkin.get("weight", 75)
    height_m = patient.get("height_cm", 170) / 100
    bmi = weight / (height_m ** 2)

    cholesterol = patient.get("cholesterol_baseline", 190)
    hdl = patient.get("hdl_baseline", 55)
    ldl = max(50, cholesterol - hdl - 30)

    glucose = checkin.get("glucose") or patient.get("glucose_baseline", 95)

    return pd.DataFrame([{
        "age": patient.get("age", 40),
        "gender": 1 if patient.get("gender", "M") == "M" else 0,
        "bmi": round(bmi, 2),
        "bp_systolic": checkin.get("bp_systolic", 120),
        "bp_diastolic": checkin.get("bp_diastolic", 80),
        "glucose": glucose,
        "cholesterol": cholesterol,
        "hdl": hdl,
        "ldl": ldl,
        "sleep_hours": checkin.get("sleep_hours", 7),
        "heart_rate": checkin.get("heart_rate", 75),
        "spo2": checkin.get("spo2", 97),
        "smoker": int(patient.get("smoker", False)),
        "family_diabetes": int(patient.get("family_history_diabetes", False)),
        "family_cardiac": int(patient.get("family_history_cardiac", False)),
        "mood": checkin.get("mood", 7),
    }])


def predict_risks(patient_dict: dict, checkin_dict: dict) -> dict:
    models, explainers = get_models()
    X = build_feature_vector(patient_dict, checkin_dict)

    risks = {}
    shap_summary = {}

    for disease in ["diabetes", "cardiac", "hypertension", "metabolic"]:
        model = models[disease]
        explainer = explainers[disease]

        prob = float(model.predict_proba(X)[0][1])
        risks[f"{disease}_risk"] = round(prob * 100, 1)

        shap_vals = explainer.shap_values(X)
        if isinstance(shap_vals, list):
            sv = shap_vals[1][0]
        else:
            sv = shap_vals[0]

        feat_shap = [(FEATURE_NAMES[i], round(float(sv[i]) * 100, 2)) for i in range(len(FEATURE_NAMES))]
        feat_shap.sort(key=lambda x: abs(x[1]), reverse=True)
        shap_summary[disease] = feat_shap[:5]

    risks["shap_values"] = json.dumps(shap_summary)
    return risks
