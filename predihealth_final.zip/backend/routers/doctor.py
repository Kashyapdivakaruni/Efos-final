from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from backend.database import get_db, Doctor, Appointment, Patient
from datetime import datetime

router = APIRouter(prefix="/api/doctors", tags=["doctors"])


@router.get("/")
def list_doctors(specialty: str | None = None, db: Session = Depends(get_db)) -> List[dict]:
    q = db.query(Doctor)
    if specialty:
        q = q.filter(Doctor.specialty.ilike(f"%{specialty}%"))
    doctors = q.order_by(Doctor.rating.desc()).all()
    return [{"id": d.id, "name": d.name, "email": d.email, "specialty": d.specialty, "rating": d.rating, "hospital": d.hospital} for d in doctors]


@router.post("/book")
def book_appointment(patient_id: int, doctor_id: int, slot: datetime, db: Session = Depends(get_db)):
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    doctor = db.query(Doctor).filter(Doctor.id == doctor_id).first()
    if not doctor:
        raise HTTPException(status_code=404, detail="Doctor not found")

    appt = Appointment(patient_id=patient_id, doctor_id=doctor_id, slot=slot, status="booked")
    db.add(appt)
    db.commit()
    db.refresh(appt)
    return {"message": "Appointment booked", "appointment_id": appt.id, "slot": appt.slot.isoformat()}
