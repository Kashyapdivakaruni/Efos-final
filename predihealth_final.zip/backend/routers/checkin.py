from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.database import get_db, Patient, CheckIn, RiskScore, HealthReport, Alert, Todo, Doctor
from backend.schemas import CheckInRequest, WhatIfRequest
from backend.ml_engine import predict_risks
from backend.rules_engine import evaluate_rules, generate_todos
from backend.ollama_service import generate_health_report
import json
from datetime import datetime

router = APIRouter(prefix="/api", tags=["checkin"])


@router.post("/checkin/{patient_id}")
async def submit_checkin(patient_id: int, req: CheckInRequest, db: Session = Depends(get_db)):
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    checkin = CheckIn(
        patient_id=patient_id,
        bp_systolic=req.bp_systolic,
        bp_diastolic=req.bp_diastolic,
        weight=req.weight,
        mood=req.mood,
        sleep_hours=req.sleep_hours,
        spo2=req.spo2,
        heart_rate=req.heart_rate,
        glucose=req.glucose,
    )
    db.add(checkin)
    db.flush()

    patient_dict = {
        "age": patient.age, "gender": patient.gender,
        "height_cm": patient.height_cm, "smoker": patient.smoker,
        "family_history_diabetes": patient.family_history_diabetes,
        "family_history_cardiac": patient.family_history_cardiac,
        "glucose_baseline": patient.glucose_baseline,
        "cholesterol_baseline": patient.cholesterol_baseline,
        "hdl_baseline": patient.hdl_baseline,
        "name": patient.name,
    }
    checkin_dict = req.dict()

    risks = predict_risks(patient_dict, checkin_dict)

    risk_score = RiskScore(
        patient_id=patient_id,
        checkin_id=checkin.id,
        diabetes_risk=risks["diabetes_risk"],
        cardiac_risk=risks["cardiac_risk"],
        hypertension_risk=risks["hypertension_risk"],
        metabolic_risk=risks["metabolic_risk"],
        shap_values=risks["shap_values"],
    )
    db.add(risk_score)
    db.flush()

    # Generate alerts
    doctor = db.query(Doctor).first()
    alerts = evaluate_rules(checkin_dict, risks)
    for a in alerts:
        db.add(Alert(
            patient_id=patient_id,
            doctor_id=doctor.id if doctor else None,
            alert_type=a["alert_type"],
            message=a["message"],
            severity=a["severity"],
        ))

    # Generate todos
    db.query(Todo).filter(Todo.patient_id == patient_id, Todo.source == "ai", Todo.is_completed == False).delete()
    todo_tasks = generate_todos(checkin_dict, risks, risks["shap_values"])
    for task in todo_tasks:
        db.add(Todo(patient_id=patient_id, task=task, source="ai"))

    # Generate health report
    report_text = await generate_health_report(patient_dict, checkin_dict, risks, risks["shap_values"])
    db.add(HealthReport(
        patient_id=patient_id,
        checkin_id=checkin.id,
        report_text=report_text,
    ))

    db.commit()

    return {
        "message": "Check-in complete!",
        "risks": {
            "diabetes_risk": risks["diabetes_risk"],
            "cardiac_risk": risks["cardiac_risk"],
            "hypertension_risk": risks["hypertension_risk"],
            "metabolic_risk": risks["metabolic_risk"],
        },
        "alerts_generated": len(alerts),
        "report": report_text,
        "shap_values": json.loads(risks["shap_values"]),
    }


@router.post("/whatif")
def what_if_simulation(req: WhatIfRequest, db: Session = Depends(get_db)):
    patient = db.query(Patient).filter(Patient.id == req.patient_id).first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    patient_dict = {
        "age": patient.age, "gender": patient.gender,
        "height_cm": patient.height_cm, "smoker": patient.smoker,
        "family_history_diabetes": patient.family_history_diabetes,
        "family_history_cardiac": patient.family_history_cardiac,
        "glucose_baseline": patient.glucose_baseline,
        "cholesterol_baseline": patient.cholesterol_baseline,
        "hdl_baseline": patient.hdl_baseline,
    }
    checkin_dict = req.dict()
    del checkin_dict["patient_id"]

    risks = predict_risks(patient_dict, checkin_dict)
    return {
        "diabetes_risk": risks["diabetes_risk"],
        "cardiac_risk": risks["cardiac_risk"],
        "hypertension_risk": risks["hypertension_risk"],
        "metabolic_risk": risks["metabolic_risk"],
    }
