import { useState } from 'react'
import axios from 'axios'

export function LabReportUpload() {
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState('')

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFile(e.target.files[0])
      setError('')
    }
  }

  const handleUpload = async () => {
    if (!file) {
      setError('Please select a file')
      return
    }

    setLoading(true)
    setError('')
    try {
      const formData = new FormData()
      formData.append('file', file)

      const res = await axios.post('/api/ingest/report', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })

      setResult(res.data)
      setFile(null)
    } catch (e: any) {
      setError(e.response?.data?.detail || 'Upload failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ padding: '20px' }}>
      <h3 style={{ fontSize: '18px', fontWeight: 700, marginBottom: '16px' }}>📄 Upload Lab Report</h3>

      {error && (
        <div style={{
          background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)',
          borderRadius: '8px', padding: '12px', marginBottom: '16px',
          color: '#fca5a5', fontSize: '13px'
        }}>{error}</div>
      )}

      <div style={{
        border: '2px dashed rgba(124,92,252,0.3)', borderRadius: '12px',
        padding: '32px', textAlign: 'center', marginBottom: '16px', cursor: 'pointer',
        background: 'rgba(124,92,252,0.05)', transition: 'all 0.3s ease'
      }} onClick={() => document.getElementById('fileInput')?.click()}>
        <input id="fileInput" type="file" onChange={handleFileChange} style={{ display: 'none' }}
          accept=".pdf,.jpg,.jpeg,.png" />
        <div style={{ fontSize: '28px', marginBottom: '8px' }}>📎</div>
        <p style={{ margin: '0 0 8px', fontSize: '14px', fontWeight: 600 }}>
          {file ? file.name : 'Click to upload or drag & drop'}
        </p>
        <p style={{ margin: 0, fontSize: '12px', color: 'var(--text-secondary)' }}>PDF, JPG, or PNG</p>
      </div>

      <button onClick={handleUpload} disabled={loading || !file}
        style={{
          width: '100%', padding: '12px', borderRadius: '8px', border: 'none',
          background: 'linear-gradient(135deg, #7c5cfc, #4f8ef7)', color: 'white',
          fontWeight: 600, fontSize: '14px', cursor: loading || !file ? 'not-allowed' : 'pointer',
          opacity: loading || !file ? 0.6 : 1
        }}>
        {loading ? 'Processing...' : 'Analyze Report'}
      </button>

      {result && (
        <div style={{ marginTop: '20px', padding: '16px', background: 'rgba(124,92,252,0.05)', borderRadius: '8px' }}>
          <h4 style={{ fontSize: '14px', fontWeight: 700, marginBottom: '12px' }}>📊 Extracted Data</h4>
          <div style={{ fontSize: '13px', lineHeight: '1.6' }}>
            <p><strong>Method:</strong> {result.method}</p>
            {result.parsed && Object.entries(result.parsed).map(([key, value]) => (
              <p key={key}><strong>{key.replace(/_/g, ' ')}:</strong> {String(value)}</p>
            ))}
            <p style={{ marginTop: '12px', color: 'var(--text-secondary)' }}>
              <em>Excerpt: {result.text_excerpt.substring(0, 100)}...</em>
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
